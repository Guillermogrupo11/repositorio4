package com.portfolio.gda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GdaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GdaApplication.class, args);
	}

}
